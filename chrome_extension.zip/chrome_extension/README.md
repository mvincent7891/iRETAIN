# SearchTool
A simple chrome extension that let's you send a selected word to your Garnish account (currently running on local host). 
